<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body class="bg-dark">
    <?php 
        require "config.php";
        $tie = "";
        $die = "";
        $ime = "";
        if(isset($_POST['btnc'])){
            $ti = $_POST['title'];
            $di = $_POST['dis'];
            $im = $_POST['img'];

            if($ti == ''){
                $tie = "title is require";
            }
            if($di == ''){
                $die = "disc is require";
            }
            if($im == ''){
                $ime = "url is require";
            }
            if($ti != ''&& $di != '' && $im != ''){
                $qu = "INSERT INTO post(title,disc,img) VALUE('$ti','$di','$im')";
                mysqli_query($db,$qu);
                header("location: panel.php");
            }
            
        }
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col"></div>
            <div class="col">
                <div class="card mt-5">
                    <div class="card-title">
                        <h5 class="text-center">Post</h5>
                    </div>  
                    <form action="post.php" method="POST">
                        <div class="card-body">
                            <div>
                                <label>Title</label>
                                <br>
                                <input type="text" pattern="[^()/><\][\\\x22,;|]+" class="form-control" name="title" placeholder="Title">
                                <span class="text-danger"><?php echo $tie;?></span>
                            </div>
                            <br>
                            <div>
                                <label>Discrption</label>
                                <br>
                                <textarea name="dis" class="form-control" pattern="[^()/><\][\\\x22,;|]+" ></textarea>
                                <span class="text-danger"><?php echo $die;?></span>
                            </div>
                            <br>
                            <div>
                                <label>Img url</label>
                                <br>
                                <input type="url" name="img" class="form-control">
                                <span class="text-danger"><?php echo $ime;?></span>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" name="btnc" class="btn btn-dark">Upload</button>
                            <a href="panel.php" class="btn btn-dark float-right">Back</a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col"></div>
        </div>
    </div>
</body>
</html>