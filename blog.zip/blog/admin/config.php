<?php 
    $db = mysqli_connect('localhost','root','','blog');
    if($db == false){
        echo 'Error';

    }
?>